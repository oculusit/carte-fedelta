const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-D6lwuqLC.js","./index-DH-ldO5h.js","./index-D0p0uSzm.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DH-ldO5h.js";const _=r("Share",{web:()=>t(()=>import("./web-D6lwuqLC.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
